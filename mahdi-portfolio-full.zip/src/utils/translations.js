// دیکشنری ترجمه‌ها - انگلیسی و فارسی
export const translations = {
  en: {
    siteMeta: {
      title: 'Mahdi - Frontend Developer & UI/UX Designer',
      description: "Mahdi's personal website - Frontend developer and UI/UX designer",
    },
    nav: {
      logo: 'Mahdi',
      home: 'Home',
      portfolio: 'Portfolio',
      contact: 'Contact',
    },
    footer: {
      rights: 'All rights reserved',
    },
    hero: {
      subtitle: 'Frontend Developer | UI Designer',
      description: 'With several years of experience designing and building modern, user-friendly websites',
      ctaPortfolio: 'View My Work',
      ctaContact: 'Contact Me',
    },
    about: {
      title: 'About Me',
      subtitle: 'Get to know my expertise and skills',
    },
    cta: {
      title: 'Ready to collaborate! 🚀',
      subtitle: "Let's start your project together",
      button: 'Get in touch now ✨',
    },
    featuredProjects: {
      title: 'Featured Projects',
      subtitle: 'A sample of my work',
      code: 'Code',
      viewProject: 'View Project',
      cafe: {
        title: 'Cafe Project',
        description: 'An online ordering system for a café, built for taking customer orders',
      },
    },
    portfolio: {
      title: 'Portfolio',
      subtitle: 'Completed Projects',
      description: 'A collection of successful projects built with modern technologies',
      searchPlaceholder: 'Search projects...',
      allProjects: 'All Projects',
      categoryLabel: 'Category',
      noProjectsInCategory: 'No projects found in this category',
      noResultsTitle: 'No results found',
      noResultsSubtitle: 'Please adjust your filters or search term',
      categories: {
        all: 'All',
        frontend: 'Frontend',
        backend: 'Backend',
        fullstack: 'Full Stack',
        other: 'Other',
      },
    },
    projectCard: {
      viewProject: 'View Project',
      viewDetails: 'View Details',
    },
    contact: {
      title: 'Contact Me',
      subtitle: 'Get in touch for collaborations and new projects',
      methods: 'Contact Methods',
      methodTitles: {
        twitter: 'Twitter',
        telegram: 'Telegram',
        instagram: 'Instagram',
      },
      form: {
        sendMessage: 'Send a Message',
        name: 'Full Name',
        namePlaceholder: 'Enter your name',
        email: 'Email',
        message: 'Message',
        messagePlaceholder: 'Write your message...',
        submit: 'Send Message',
        submitting: 'Sending...',
        success: '✅ Your message was sent successfully!',
        error: '❌ Failed to send message. Please try again.',
      },
    },
    siteInfo: {
      name: 'Mahdi',
      title: 'Frontend Developer & UI/UX Designer',
      description: 'React, Vue, and WordPress development specialist with a background in UI design',
      location: 'Qom, Iran',
    },
    projects: {
      1: { title: 'Online Store', description: 'A complete e-commerce store built with React and Node.js, featuring product management, a shopping cart, and online payments' },
      2: { title: 'Admin Dashboard', description: 'An advanced admin panel with charts and analytical reports for business management' },
      3: { title: 'Weather App', description: 'Displays live weather conditions via an API, with a clean design and engaging animations' },
      4: { title: 'Authentication System', description: 'A complete sign-up, login, and user management system built with strong security' },
      5: { title: 'Personal Blog', description: 'A blog with article management, commenting, and advanced search' },
      6: { title: 'Café Gaf Ordering System', description: 'An online ordering system for a café, with menu selection and order submission' },
    },
    seo: {
      home: {
        title: 'Mahdi - Frontend Developer & UI/UX Designer',
        description: "Mahdi's personal portfolio - frontend developer specializing in React, building modern, user-friendly websites.",
      },
      portfolio: {
        title: 'Portfolio | Mahdi - Frontend Developer',
        description: 'A collection of web development projects by Mahdi, including full-stack apps, dashboards, and e-commerce stores built with React and Node.js.',
      },
      contact: {
        title: 'Contact | Mahdi - Frontend Developer',
        description: 'Get in touch with Mahdi for frontend development and UI/UX design collaborations and projects.',
      },
    },
    notFound: {
      title: 'Page Not Found',
      description: "The page you're looking for doesn't exist or has been moved.",
      backHome: 'Back to Home',
    },
  },
  fa: {
    siteMeta: {
      title: 'مهدی - توسعه‌دهنده فرانت‌اند و طراح UI/UX',
      description: 'وب‌سایت شخصی مهدی - توسعه‌دهنده فرانت‌اند و طراح رابط کاربری',
    },
    nav: {
      logo: 'مهدی',
      home: 'خانه',
      portfolio: 'نمونه کارها',
      contact: 'تماس با من',
    },
    footer: {
      rights: 'تمامی حقوق محفوظ است',
    },
    hero: {
      subtitle: 'توسعه‌دهنده فرانت‌اند | طراح رابط کاربری',
      description: 'با بیش از چند سال تجربه در طراحی و توسعه وب‌سایت‌های مدرن و کاربرپسند',
      ctaPortfolio: 'مشاهده نمونه کارها',
      ctaContact: 'تماس با من',
    },
    about: {
      title: 'درباره من',
      subtitle: 'با تخصص‌ها و مهارت‌های من آشنا شوید',
    },
    cta: {
      title: 'آماده همکاری هستیم! 🚀',
      subtitle: 'پروژه خود را با ما شروع کنید',
      button: 'همین حالا تماس بگیرید ✨',
    },
    featuredProjects: {
      title: 'پروژه‌ برگزیده',
      subtitle: 'نمونه‌ای از کار من',
      code: 'کد',
      viewProject: 'مشاهده پروژه',
      cafe: {
        title: 'پروژه کافه',
        description: 'سیستم سفارش آنلاین کافه برای ثبت سفارش مشتریان',
      },
    },
    portfolio: {
      title: 'نمونه کارها',
      subtitle: 'پروژه‌های انجام شده',
      description: 'مجموعه‌ای از پروژه‌های موفق که با تکنولوژی‌های روز دنیا پیاده‌سازی شده‌اند',
      searchPlaceholder: 'جستجو در پروژه‌ها...',
      allProjects: 'همه پروژه‌ها',
      categoryLabel: 'دسته‌بندی',
      noProjectsInCategory: 'پروژه‌ای در این دسته یافت نشد',
      noResultsTitle: 'نتیجه‌ای یافت نشد',
      noResultsSubtitle: 'لطفاً فیلترها یا عبارت جستجو را تغییر دهید',
      categories: {
        all: 'همه',
        frontend: 'فرانت‌اند',
        backend: 'بک‌اند',
        fullstack: 'فول‌استک',
        other: 'دیگر',
      },
    },
    projectCard: {
      viewProject: 'مشاهده پروژه',
      viewDetails: 'مشاهده جزئیات',
    },
    contact: {
      title: 'تماس با من',
      subtitle: 'برای همکاری و پروژه‌های جدید با من در ارتباط باشید',
      methods: 'راه‌های ارتباطی',
      methodTitles: {
        twitter: 'توییتر',
        telegram: 'تلگرام',
        instagram: 'اینستاگرام',
      },
      form: {
        sendMessage: 'ارسال پیام',
        name: 'نام و نام خانوادگی',
        namePlaceholder: 'نام خود را وارد کنید',
        email: 'ایمیل',
        message: 'پیام',
        messagePlaceholder: 'پیام خود را بنویسید...',
        submit: 'ارسال پیام',
        submitting: 'در حال ارسال...',
        success: '✅ پیام شما با موفقیت ارسال شد!',
        error: '❌ خطا در ارسال پیام. لطفاً دوباره تلاش کنید.',
      },
    },
    siteInfo: {
      name: 'آقا مهدی',
      title: 'توسعه‌دهنده فرانت‌اند و طراح UI/UX',
      description: 'متخصص React، Vue و توسعه وردپرس با تجربه طراحی رابط کاربری',
      location: 'قم، ایران',
    },
    projects: {
      1: { title: 'فروشگاه آنلاین', description: 'یک فروشگاه کامل با React و Node.js با قابلیت مدیریت محصولات، سبد خرید و پرداخت آنلاین' },
      2: { title: 'داشبورد مدیریتی', description: 'پنل ادمین پیشرفته با نمودارها و گزارش‌های تحلیلی برای مدیریت کسب‌وکار' },
      3: { title: 'اپلیکیشن آب‌وهوا', description: 'نمایش وضعیت آب‌وهوا با استفاده از API با طراحی زیبا و انیمیشن‌های جذاب' },
      4: { title: 'سیستم احراز هویت', description: 'سیستم کامل ثبت‌نام، ورود و مدیریت کاربران با امنیت بالا' },
      5: { title: 'وبلاگ شخصی', description: 'وبلاگ با قابلیت مدیریت مقالات، کامنت‌گذاری و جستجوی پیشرفته' },
      6: { title: 'سیستم سفارش کافه گاف', description: 'سیستم سفارش‌گیری آنلاین کافه با امکان انتخاب منو و ارسال سفارش' },
    },
    seo: {
      home: {
        title: 'مهدی - توسعه‌دهنده فرانت‌اند و طراح UI/UX',
        description: 'نمونه‌کار شخصی مهدی - توسعه‌دهنده فرانت‌اند با تخصص در React، طراحی و توسعه وب‌سایت‌های مدرن و کاربرپسند',
      },
      portfolio: {
        title: 'نمونه کارها | مهدی - توسعه‌دهنده فرانت‌اند',
        description: 'مجموعه‌ای از پروژه‌های توسعه وب توسط مهدی، شامل اپلیکیشن‌های فول‌استک، داشبورد و فروشگاه آنلاین با React و Node.js',
      },
      contact: {
        title: 'تماس با من | مهدی - توسعه‌دهنده فرانت‌اند',
        description: 'برای همکاری و پروژه‌های توسعه فرانت‌اند و طراحی UI/UX با مهدی در ارتباط باشید',
      },
    },
    notFound: {
      title: 'صفحه پیدا نشد',
      description: 'صفحه‌ای که دنبالش می‌گردید وجود نداره یا جابه‌جا شده.',
      backHome: 'بازگشت به خانه',
    },
  },
};
